import java.util.*;
import java.io.*;

class Symbol {
    int entryNo;
    String symbol;
    int address;
    int length;

    Symbol(int entryNo, String symbol, int address, int length) {
        this.entryNo = entryNo;
        this.symbol = symbol;
        this.address = address;
        this.length = length;
    }
}

public class symbol {

    public static void main(String[] args) {
        String fileName = "program.txt";  

        List<Symbol> symbolTable = new ArrayList<>();
        int locationCounter = 0;
        int entryNo = 1;

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

               
                if (line.equalsIgnoreCase("END")) {
                    continue;
                }

                String[] parts = line.split("\\s+");

                if (parts[0].equalsIgnoreCase("START")) {
                    locationCounter = Integer.parseInt(parts[1]);
                    continue;
                }

                String label = null;
                String instruction = null;
                int length = 1;

                if (parts.length == 1) {
                    label = parts[0];
                } else if (parts.length == 2) {
                    if (!isOpcode(parts[0])) {
                        label = parts[0];
                        instruction = parts[1];
                    } else {
                        instruction = parts[0];
                    }
                } else if (parts.length >= 3) {
                    label = parts[0];
                    instruction = parts[1];
                }

                // Check if the label is not an opcode before adding it to the symbol table
                if (label != null && !isOpcode(label)) {
                    if ("DS".equalsIgnoreCase(instruction)) {
                        length = Integer.parseInt(parts[2]);
                    }
                    symbolTable.add(new Symbol(entryNo++, label, locationCounter, length));
                    locationCounter += length;
                } else {
                    locationCounter++;
                }
            }

            // Print symbol table
            System.out.printf("%-10s %-10s %-10s %-10s%n", "Entry No.", "Symbol", "Address", "Length");
            System.out.println("--------------------------------------------");
            for (Symbol sym : symbolTable) {
                System.out.printf("%-10d %-10s %-10d %-10d%n", sym.entryNo, sym.symbol, sym.address, sym.length);
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    // This method checks whether the word is a valid opcode
    static boolean isOpcode(String word) {
        String[] opcodes = {"MOVER", "MOVEM", "ADD", "SUB", "MULT", "DIV", "READ", "PRINT"};
        for (String opcode : opcodes) {
            if (opcode.equalsIgnoreCase(word)) {
                return true;
            }
        }
        return false;
    }
}

