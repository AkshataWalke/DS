#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cctype>

using namespace std;

// Structure to represent a single entry in the Quadruple Table
struct Quadruple {
    int index;        // Table index
    string operator_; // The operator (e.g. `+`, `-`, `*`, `/`)
    string operand1;  // The first operand
    string operand2;  // The second operand
    string result;    // The result variable (e.g., temporary variables `t1`, `t2`, etc.)

    // Constructor to initialize a Quadruple
    Quadruple(int idx, string op, string op1, string op2, string res)
        : index(idx), operator_(op), operand1(op1), operand2(op2), result(res) {}
};

// Function to parse an expression into components (e.g., operands and operators)
vector<string> parseExpression(const string& expr) {
    vector<string> tokens;
    string token;
    
    for (char ch : expr) {
        if (isspace(ch)) continue;  // Skip spaces
        if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            if (!token.empty()) {
                tokens.push_back(token);  // Add the operand
                token.clear();
            }
            tokens.push_back(string(1, ch));  // Add the operator
        } else {
            token += ch;  // Add character to the current operand
        }
    }
    if (!token.empty()) tokens.push_back(token);  // Add the last operand
    return tokens;
}

// Function to generate the Quadruple Table for a given arithmetic expression
void generateQuadrupleTable(const string& expr) {
    vector<string> tokens = parseExpression(expr);
    vector<Quadruple> quadruples;
    int tempIndex = 1;
    int idx = 1;

    // We need to handle the expression step by step to generate intermediate code
    vector<string> operands;
    vector<string> operators;

    // Process the tokens and generate intermediate code
    for (int i = 0; i < tokens.size(); i++) {
        if (tokens[i] == "+" || tokens[i] == "-" || tokens[i] == "*" || tokens[i] == "/") {
            // If it's an operator, store it
            operators.push_back(tokens[i]);
        } else {
            // If it's an operand, store it
            operands.push_back(tokens[i]);

            // If we have two operands and one operator, generate the quadruple
            if (operands.size() == 2 && operators.size() == 1) {
                string result = "t" + to_string(tempIndex++);
                quadruples.push_back(Quadruple(idx++, operators.back(), operands[0], operands[1], result));
                operands.clear();  // Clear operands for the next operation
                operators.clear(); // Clear operators for the next operation
                operands.push_back(result); // Push the result of this operation for further use
            }
        }
    }

    // If we have any remaining operands and operators, generate the final result
    if (!operands.empty()) {
        string result = operands[0];
        quadruples.push_back(Quadruple(idx, "+", result, "", expr.substr(0, 1)));
    }

    // Output the Quadruple Table
    cout << "Quadruple Table:\n";
    cout << "Index\tOperator\tOperand1\tOperand2\tResult\n";
    for (const auto& quad : quadruples) {
        cout << quad.index << "\t" << quad.operator_ << "\t\t"
             << quad.operand1 << "\t\t" << quad.operand2 << "\t\t" << quad.result << endl;
    }
}

// Main function to take input from the user and generate the Quadruple Table
int main() {
    string expr;

    // Take user input for the expression
    cout << "Enter an arithmetic expression (e.g., a = b * -c + b * -c): ";
    getline(cin, expr);  // Read the full expression

    // Generate the Quadruple Table for the given expression
    generateQuadrupleTable(expr);

    return 0;
}

