//write a program using c++ to generate intermediate code in the from of three address code and quadraple //from for assignment statement
#include <iostream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

// Structure to represent a single entry in the Quadruple Table
struct Quadruple {
    int index;        // Table index
    string operator_; // The operator (e.g. `+`, `-`, `*`, `/`)
    string operand1;  // The first operand
    string operand2;  // The second operand
    string result;    // The result variable (e.g., temporary variables `t1`, `t2`, etc.)

    // Constructor to initialize a Quadruple
    Quadruple(int idx, string op, string op1, string op2, string res)
        : index(idx), operator_(op), operand1(op1), operand2(op2), result(res) {}
};

// Function to generate the Quadruple Table for the expression a = b * -c + b * -c
void generateQuadrupleTable(const string& var1, const string& var2, const string& var3) {
    vector<Quadruple> quadruples;
    int tempIndex = 1;

    // Step 1: Generate the negation of c (represented as "- c")
    string result1 = "t" + to_string(tempIndex++);
    quadruples.push_back(Quadruple(tempIndex - 1, "-", var3, "-", result1));

    // Step 2: Generate the first multiplication (b * -c)
    string result2 = "t" + to_string(tempIndex++);
    quadruples.push_back(Quadruple(tempIndex - 1, "*", var2, result1, result2));

    // Step 3: Generate the negation of c again
    string result3 = "t" + to_string(tempIndex++);
    quadruples.push_back(Quadruple(tempIndex - 1, "-", var3, "-", result3));

    // Step 4: Generate the second multiplication (b * -c)
    string result4 = "t" + to_string(tempIndex++);
    quadruples.push_back(Quadruple(tempIndex - 1, "*", var2, result3, result4));

    // Step 5: Generate the final addition (t2 + t4)
    string finalResult = var1;
    quadruples.push_back(Quadruple(tempIndex++, "+", result2, result4, finalResult));
    
    // Output the Quadruple Table
    cout << "Quadruple Table:\n";
    cout << "Index\tOperator\tOperand1\tOperand2\tResult\n";
    for (const auto& quad : quadruples) {
        cout << quad.index << "\t" << quad.operator_ << "\t\t"
             << quad.operand1 << "\t\t" << quad.operand2 << "\t\t" << quad.result << endl;
    }
}

// Main function to demonstrate the generation of Quadruple table
int main() {
    // Example input for the expression "a = b * -c + b * -c"
    string var1 = "a"; // Result variable
    string var2 = "b"; // Operand 1 for multiplication
    string var3 = "c"; // Operand 2 for multiplication (c is negated)
    
    generateQuadrupleTable(var1, var2, var3);
    
    return 0;
}

