#include <iostream>
#include <cctype>
#include <string>

using namespace std;

string input;    // Input string
int index = 0;    // Pointer to the current character in the input

// Function prototypes
bool parseE();
bool parseEPrime();
bool parseT();   
bool parseTPrime();
bool parseF();

int main() {
    cout << "Enter an expression: ";
    getline(cin, input);  // Read the entire line as input

    // Start parsing from the E (Expression) non-terminal
    if (parseE() && index == input.length()) {
        cout << "Sentence successfully parsed." << endl;
    } else {
        cout << "Sentence failed to parse." << endl;
    }

    return 0;
}

// E -> T E'
bool parseE() {
    if (parseT()) {
        return parseEPrime();
    }
    return false;
}

// E' -> + T E' | ε
bool parseEPrime() {
    if (index < input.length() && input[index] == '+') {
        index++; // consume '+'
        if (parseT()) {
            return parseEPrime();
        }
        return false;
    }
    return true; // epsilon (empty production)
}

// T -> F T'
bool parseT() {
    if (parseF()) {
        return parseTPrime();
    }
    return false;
}

// T' -> * F T' | ε
bool parseTPrime() {
    if (index < input.length() && input[index] == '*') {
        index++; // consume '*'
        if (parseF()) {
            return parseTPrime();
        }
        return false;
    }
    return true; // epsilon (empty production)
}

// F -> ( E ) | id
bool parseF() {
    if (index < input.length() && input[index] == '(') {
        index++; // consume '('
        if (parseE()) {
            if (index < input.length() && input[index] == ')') {
                index++; // consume ')'
                return true;
            }
        }
        return false;
    } else if (index < input.length() && isalpha(input[index])) {
        // Match an identifier (id)
        index++; // consume the identifier
        return true;
    }
    return false;
}

