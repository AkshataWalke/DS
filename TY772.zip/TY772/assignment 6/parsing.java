import java.util.Scanner;

public class parsing {
    private static String input;    // Input string
    private static int index = 0;   // Pointer to the current character in the input

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an expression: ");
        input = scanner.nextLine().trim();
        
        // Start parsing from the E (Expression) non-terminal
        if (parseE() && index == input.length()) {
            System.out.println("Sentence successfully parsed.");
        } else {
            System.out.println("Sentence failed to parse.");
        }
    }

    // E -> T E'
    private static boolean parseE() {
        if (parseT()) {
            return parseEPrime();
        }
        return false;
    }

    // E' -> + T E' | ε
    private static boolean parseEPrime() {
        if (index < input.length() && input.charAt(index) == '+') {
            index++; // consume '+'
            if (parseT()) {
                return parseEPrime();
            }
            return false;
        }
        return true; // epsilon (empty production)
    }

    // T -> F T'
    private static boolean parseT() {
        if (parseF()) {
            return parseTPrime();
        }
        return false;
    }

    // T' -> * F T' | ε
    private static boolean parseTPrime() {
        if (index < input.length() && input.charAt(index) == '*') {
            index++; // consume '*'
            if (parseF()) {
                return parseTPrime();
            }
            return false;
        }
        return true; // epsilon (empty production)
    }

    // F -> ( E ) | id
    private static boolean parseF() {
        if (index < input.length() && input.charAt(index) == '(') {
            index++; // consume '('
            if (parseE()) {
                if (index < input.length() && input.charAt(index) == ')') {
                    index++; // consume ')'
                    return true;
                }
            }
            return false;
        } else if (index < input.length() && Character.isAlphabetic(input.charAt(index))) {
            // Match an identifier (id)
            index++; // consume the identifier
            return true;
        }
        return false;
    }
}

