#include<stdio.h>
void fun(){
	printf("Hello this is user defined function");
}
int main(){
	//variable
	int rno=77;
	float marks=7.88;
	printf("Akshada Phopse");
	fun();
	return 0;
	/*hello this
	is multiline comment*/
}
